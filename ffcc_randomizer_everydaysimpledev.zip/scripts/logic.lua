-- The same rules as the AP world's logic (worlds/ffcc/rules.py).

-- $stage_key|<code>: a dungeon's chests are in logic once its key is found,
-- or always when the seed has no stage keys ("Stage Keys Required" off).
function stage_key(code)
    local on = Tracker:FindObjectForCode("stage_keys_on")
    if not (on and on.Active) then
        return true
    end
    local key = Tracker:FindObjectForCode("key_" .. code)
    return key ~= nil and key.Active
end

-- $river|<code>: a dungeon on a spot across the Jegon River (Plains of Fum,
-- Rebena Plains, the Abyss) needs the Ring of Life and Veo Lu Sluice, so the
-- river can be refilled when it dries up in Year 5. With Shuffle Loading
-- Zones the spot comes from the slot data (SetWorldZones).
local DUNGEON_OF_CODE = {
    rbp = "River Belle Path",
    gw = "Goblin Wall",
    moc = "The Mine of Cathuriges",
    tmf = "The Mushroom Forest",
    tida = "Tida",
    mm = "Moschet Manor",
    mk = "Mount Kilanda",
    dc = "Daemon's Court",
    sc = "Selepation Cave",
    vls = "Veo Lu Sluice",
    ld = "Lynari Desert",
    cc = "Conall Curach",
    rtr = "Rebena Te Ra",
    mv = "Mount Vellenge",
}
local ACROSS_RIVER = {
    ["Selepation Cave"] = true,
    ["Daemon's Court"] = true,
    ["Conall Curach"] = true,
    ["Rebena Te Ra"] = true,
    ["Mount Vellenge"] = true,
}
local SPOT_OF = {}      -- dungeon -> world-map spot, empty = every dungeon on its own

function SetWorldZones(zones)
    SPOT_OF = {}
    if type(zones) == "table" then
        for spot, dungeon in pairs(zones) do
            SPOT_OF[dungeon] = spot
        end
    end
end

function river(code)
    local dungeon = DUNGEON_OF_CODE[code]
    if not ACROSS_RIVER[SPOT_OF[dungeon] or dungeon] then
        return true
    end
    local ring = Tracker:FindObjectForCode("ring_of_life")
    return ring ~= nil and ring.Active and stage_key("vls")
end

-- $timed_chests: Rebena Te Ra chests 6 and 9 need tight timing alone. They are
-- in logic only with the "Rebena Te Ra Timed Chests" option. Otherwise they
-- show as a sequence break.
TIMED_CHESTS_ON = false

function timed_chests()
    if TIMED_CHESTS_ON then
        return true
    end
    return AccessibilityLevel.SequenceBreak
end

-- $progression_cycle|<cycle>: cycles past the "Progression Cycles" option only
-- hold filler, so they show as a sequence break (safe to skip).
PROGRESSION_CYCLES = 3

function progression_cycle(cycle)
    if tonumber(cycle) <= PROGRESSION_CYCLES then
        return true
    end
    return AccessibilityLevel.SequenceBreak
end

-- $chests_shown: with "Monster Hunt Checks" and "Chest Checks" off the
-- enemies are the only checks and the chests are gone, so their map pins are hidden.
CHESTS_SHOWN = true

function chests_shown()
    return CHESTS_SHOWN
end

-- $shops_shown: the shop pins of "Shop Checks"
SHOPS_SHOWN = false

function shops_shown()
    return SHOPS_SHOWN
end

-- $year|<n>: the game is in year n or later (the Year Tracker, which the
-- client keeps up to date)
function year(n)
    local tracker = Tracker:FindObjectForCode("year_tracker")
    return tracker ~= nil and tracker.CurrentStage + 1 >= tonumber(n)
end

-- $across_river: the Fields of Fum, across the Jegon River like the
-- dungeons there (see river)
function across_river()
    local ring = Tracker:FindObjectForCode("ring_of_life")
    return ring ~= nil and ring.Active and stage_key("vls")
end

-- $enemies_shown|<enemy or boss>: the enemy pins of "Monster Hunt Checks",
-- bosses only with "Monster Hunt Bosses".
ENEMIES_SHOWN = false
HUNT_BOSSES = true

function enemies_shown(kind)
    return ENEMIES_SHOWN and (kind ~= "boss" or HUNT_BOSSES)
end

-- $exit_shown|<option>: the pin of an exit that only exists with that
-- option (Lynari Desert North Exit). archipelago.lua fills EXITS_ON from
-- the slot data.
EXITS_ON = {}

function exit_shown(option)
    return EXITS_ON[option] == true
end
