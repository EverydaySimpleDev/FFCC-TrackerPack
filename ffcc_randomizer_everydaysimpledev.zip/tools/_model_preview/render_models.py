"""blender --background --python render_models.py -- <models dir> <out dir> <model> [<model> ...]
Imports each FFCC item model with the ffcc_importer add-on, renders it, and
writes its UV layout."""
import sys, os, math
import bpy
from mathutils import Vector

args = sys.argv[sys.argv.index("--") + 1:]
models_dir, out_dir, names = args[0], args[1], args[2:]
for name in names:
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.preferences.addon_enable(module="ffcc_importer-main")
    scene = bpy.context.scene
    chm = os.path.join(models_dir, name, f"{name}_root.chm")
    bpy.ops.import_scene.ffcc_chm(filepath=chm)
    meshes = [o for o in scene.objects if o.type == "MESH"]
    print(name, "meshes:", [(o.name, len(o.data.polygons), [m.name for m in o.data.materials]) for o in meshes])
    if not meshes:
        continue
    # frame the model
    lo = Vector((1e9,) * 3); hi = Vector((-1e9,) * 3)
    for o in meshes:
        for c in o.bound_box:
            w = o.matrix_world @ Vector(c)
            lo = Vector(map(min, lo, w)); hi = Vector(map(max, hi, w))
    centre, size = (lo + hi) / 2, max((hi - lo).length, 0.001)
    cam = bpy.data.objects.new("cam", bpy.data.cameras.new("cam")); scene.collection.objects.link(cam)
    cam.location = centre + Vector((size * 0.9, -size * 1.3, size * 0.8))
    cam.rotation_euler = (centre - cam.location).to_track_quat("-Z", "Y").to_euler()
    scene.camera = cam
    sun = bpy.data.objects.new("sun", bpy.data.lights.new("sun", "SUN")); scene.collection.objects.link(sun)
    sun.rotation_euler = (math.radians(50), 0, math.radians(30)); sun.data.energy = 3
    world = bpy.data.worlds.new("w"); scene.world = world; world.color = (0.25, 0.28, 0.35)
    scene.render.engine = "BLENDER_EEVEE" if "BLENDER_EEVEE" in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items.keys() else scene.render.engine
    scene.render.resolution_x = scene.render.resolution_y = 384
    scene.render.filepath = os.path.join(out_dir, f"{name}_render.png")
    bpy.ops.render.render(write_still=True)
    # UV layout
    for o in meshes:
        bpy.context.view_layer.objects.active = o
        o.select_set(True)
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="SELECT")
    bpy.ops.uv.export_layout(filepath=os.path.join(out_dir, f"{name}_uv.png"), size=(256, 256), opacity=0.0)
    bpy.ops.object.mode_set(mode="OBJECT")
