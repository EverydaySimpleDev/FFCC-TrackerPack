"""
The "Bonus Rewards" tab: for every dungeon, its four bonus tiers in the
dungeon's current cycle - the points one player needs, the four items the tier
offers, which of them have been picked, and (green) which tiers the run being
played has reached so far.

Data comes from the AP world: bonus_table.py (thresholds, vanilla pools, item
names) and, at run time, the seed's pools from the slot data ("bonus_pools")
the picks the FFCC client records in data storage (ffcc_bonus_<team>_<slot>
= {dungeon: {"tiers": {cycle: best tier}, "picked": [item ids]}}) and the
current run's score (ffcc_bonus_live_<team>_<slot> = {dungeon, cycle, score}). Item icons
are images/bonus/*.png from the randomizer's itemicons.py.

Writes scripts/bonus.lua, images/bonus/tier.png and the tab in every
layouts/dungeon_maps*.json, and loads the script from scripts/init.lua.
"""

import importlib.util
import json
import math
import os

TAB_TITLE = "Bonus Rewards"
SOLO_FACTOR = 1.35          # bonus points x this, compared with a threshold
LUA_TEMPLATE = r'''-- The Bonus Rewards tab.

BONUS_DUNGEONS = {
%(dungeons)s
}

-- the vanilla pools: 8 entries of 4 item ids. A seed's own pools replace these
BONUS_VANILLA = {
%(pools)s
}

BONUS_ITEM_NAMES = {
%(names)s
}

BONUS_ITEM_ICONS = {
%(icons)s
}

local CYCLE_START = {0, 2, 4}           -- entry offered = cycle start + tier
local pools = BONUS_VANILLA
local records = {}                      -- picks, from the FFCC client
local live = {}                         -- the current run: {dungeon, cycle, score}
local marks = {}                        -- dungeon -> {item id = true}, marked by clicking
local slots = {}                        -- code -> {dungeon, tier, index, id}
local labels = {}                       -- code -> {dungeon, tier}

local function item_name(id)
    return BONUS_ITEM_NAMES[id] or string.format("item 0x%%03x", id)
end

local function make_item(code)
    local item = ScriptHost:CreateLuaItem()
    item.Name = ""
    item.Icon = ImageReference:FromPackRelativePath("images/bonus/tier.png")
    item.CanProvideCodeFunc = function(self, wanted) return wanted == code end
    item.ProvidesCodeFunc = function(self, wanted) return 0 end
    item.OnLeftClickFunc = function(self) end
    item.OnRightClickFunc = function(self) end
    return item
end

-- Clicking an item marks it collected (left) or unmarks it (right), for games
-- played without the AP client. Picks the client recorded stay picked.
local function set_mark(dungeon, id, on)
    if id == nil then return end
    marks[dungeon] = marks[dungeon] or {}
    marks[dungeon][id] = on or nil
    BonusRefresh()
end

for dungeon, info in pairs(BONUS_DUNGEONS) do
    for tier = 1, 4 do
        local code = "bonus_" .. info.code .. "_t" .. tier
        labels[code] = {dungeon = dungeon, tier = tier, item = make_item(code)}
        for index = 1, 4 do
            local slot_code = code .. "_" .. index
            local slot = {dungeon = dungeon, tier = tier, index = index, item = make_item(slot_code)}
            slot.item.OnLeftClickFunc = function(self)
                local marked = slot.id and marks[dungeon] and marks[dungeon][slot.id]
                set_mark(dungeon, slot.id, not marked)
            end
            slot.item.OnRightClickFunc = function(self) set_mark(dungeon, slot.id, false) end
            slots[slot_code] = slot
        end
    end
    -- the dungeon's marks are saved with the tracker state, on its tier 1 label
    local holder = labels["bonus_" .. info.code .. "_t1"].item
    holder.SaveFunc = function(self)
        local ids = {}
        for id in pairs(marks[dungeon] or {}) do table.insert(ids, id) end
        return {marked = ids}
    end
    holder.LoadFunc = function(self, data)
        marks[dungeon] = {}
        if type(data) == "table" and type(data.marked) == "table" then
            for _, id in pairs(data.marked) do marks[dungeon][math.floor(id)] = true end
        end
        BonusRefresh()
    end
end

local function current_cycle(dungeon)
    local obj = Tracker:FindObjectForCode("cycle_" .. BONUS_DUNGEONS[dungeon].code)
    local stage = obj and obj.CurrentStage or 0
    if stage < 1 then return 1 end
    return math.min(stage, 3)
end

local function picked(dungeon, id)
    local record = records[dungeon]
    if type(record) ~= "table" or type(record.picked) ~= "table" then return false end
    for _, v in pairs(record.picked) do
        if math.floor(v) == id then return true end
    end
    return false
end

local function marked(dungeon, id)
    return marks[dungeon] ~= nil and marks[dungeon][id] == true
end

-- the current run's score in `dungeon`, or nil when not playing it
local function live_score(dungeon)
    if type(live) ~= "table" or live.dungeon ~= dungeon or type(live.score) ~= "number" then return nil end
    return math.floor(live.score)
end

function BonusRefresh()
    for _, label in pairs(labels) do
        local info = BONUS_DUNGEONS[label.dungeon]
        local cycle = current_cycle(label.dungeon)
        local points = info.points[label.tier]
        local score = live_score(label.dungeon)
        label.item.Name = string.format("%%s - Cycle %%d, tier %%d: %%d+ bonus points (one player)",
                                        label.dungeon, cycle, label.tier, points)
            .. (score and string.format(" - this run: %%d", score) or "")
        label.item:SetOverlay(tostring(points))
        if score and score >= points then
            label.item:SetOverlayColor("#44ff44")
        else
            label.item:SetOverlayColor("#ffffff")
        end
    end
    for _, slot in pairs(slots) do
        local cycle = current_cycle(slot.dungeon)
        local entry = (pools[slot.dungeon] or BONUS_VANILLA[slot.dungeon])[CYCLE_START[cycle] + slot.tier]
        local id = entry and math.floor(entry[slot.index]) or nil
        slot.id = id
        if id then
            local state = picked(slot.dungeon, id) and " (picked)" or marked(slot.dungeon, id) and " (marked)" or ""
            slot.item.Name = item_name(id) .. state
            slot.item.Icon = ImageReference:FromPackRelativePath("images/bonus/" .. (BONUS_ITEM_ICONS[id] or "tier.png"))
            slot.item.IconMods = state ~= "" and "" or "@disabled"
        end
    end
end

for dungeon, info in pairs(BONUS_DUNGEONS) do
    ScriptHost:AddWatchForCode("bonus cycle " .. info.code, "cycle_" .. info.code, function() BonusRefresh() end)
end

local function bonus_key()
    return "ffcc_bonus_" .. Archipelago.TeamNumber .. "_" .. Archipelago.PlayerNumber
end

local function live_key()
    return "ffcc_bonus_live_" .. Archipelago.TeamNumber .. "_" .. Archipelago.PlayerNumber
end

local function on_records(key, value)
    if key == bonus_key() then
        records = type(value) == "table" and value or {}
    elseif key == live_key() then
        live = type(value) == "table" and value or {}
    else
        return
    end
    BonusRefresh()
end

if Archipelago and Archipelago.AddSetReplyHandler then
    Archipelago:AddClearHandler("bonus rewards", function(slot_data)
        pools = BONUS_VANILLA
        if slot_data and type(slot_data.bonus_pools) == "table" then
            pools = {}
            for dungeon, entries in pairs(slot_data.bonus_pools) do
                pools[dungeon] = entries
            end
        end
        records = {}
        live = {}
        Archipelago:SetNotify({bonus_key(), live_key()})
        Archipelago:Get({bonus_key(), live_key()})
        BonusRefresh()
    end)
    Archipelago:AddRetrievedHandler("bonus rewards", on_records)
    Archipelago:AddSetReplyHandler("bonus rewards", function(key, value) on_records(key, value) end)
end

BonusRefresh()
'''


def _load_table(world):
    spec = importlib.util.spec_from_file_location("ffcc_bonus_table", os.path.join(world, "bonus_table.py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _solo_points(threshold):
    points = math.ceil(threshold / SOLO_FACTOR)
    while points > 0 and (points - 1) * SOLO_FACTOR >= threshold:
        points -= 1
    while points * SOLO_FACTOR < threshold:
        points += 1
    return points


def _lua_str(text):
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _tier_image(path):
    """A dark rounded square for the tier labels (the points are its overlay)."""
    from PIL import Image, ImageDraw
    image = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    ImageDraw.Draw(image).rounded_rectangle((1, 1, 30, 30), radius=6, fill=(40, 46, 60, 255),
                                           outline=(150, 150, 170, 255), width=2)
    image.save(path)


def write(pack, world, dungeons):
    """`dungeons`: gen_pack's DUNGEONS ({name: (map, cycle code, colour)})."""
    table = _load_table(world)
    icons = json.load(open(os.path.join(pack, "images", "bonus", "item_icons.json"), encoding="utf-8"))
    _tier_image(os.path.join(pack, "images", "bonus", "tier.png"))

    order = [d for d in dungeons if d in table.BONUS_TABLE]
    dungeon_lines, pool_lines = [], []
    for name in order:
        thresholds, entries = table.BONUS_TABLE[name]
        code = dungeons[name][1]
        points = ", ".join(str(_solo_points(t)) for t in thresholds)
        dungeon_lines.append(f"    [{_lua_str(name)}] = {{code = {_lua_str(code)}, points = {{{points}}}}},")
        rows = ", ".join("{" + ", ".join(str(v) for v in entry) + "}" for entry in entries)
        pool_lines.append(f"    [{_lua_str(name)}] = {{{rows}}},")
    name_lines = [f"    [{v}] = {_lua_str(n)}," for v, n in sorted(table.ITEM_NAMES.items())]
    icon_lines = [f"    [{int(k, 16)}] = {_lua_str(v)}," for k, v in sorted(icons.items())]
    lua = LUA_TEMPLATE % {"dungeons": "\n".join(dungeon_lines), "pools": "\n".join(pool_lines),
                          "names": "\n".join(name_lines), "icons": "\n".join(icon_lines)}
    with open(os.path.join(pack, "scripts", "bonus.lua"), "w", encoding="utf-8") as f:
        f.write(lua)

    # the tab: the dungeons in rows of three, each a 5 x 4 grid (tier label + 4 items)
    groups = []
    for name in order:
        code = dungeons[name][1]
        rows = [[f"bonus_{code}_t{t}"] + [f"bonus_{code}_t{t}_{i}" for i in range(1, 5)] for t in range(1, 5)]
        groups.append({"type": "group", "header": name, "content": {
            "type": "itemgrid", "item_margin": "2,2", "item_size": 30, "rows": rows}})
    # The tab can't scroll, so it stays three rows high: the first nine
    # dungeons in rows of three, the rest two per row to their right.
    grid = [groups[k:k + 3] for k in range(0, 9, 3)]
    for k, group in enumerate(groups[9:]):
        grid[k // 2].append(group)
    rows = [{"type": "array", "orientation": "horizontal", "margin": "4,4", "content": row}
            for row in grid]
    tab = {"title": TAB_TITLE, "content": {"type": "container", "content": {
        "type": "array", "orientation": "vertical", "content": rows}}}
    # every version of the dungeon-maps layout (the Map Options buttons switch
    # between them) gets the tab
    layouts = os.path.join(pack, "layouts")
    for file_name in sorted(os.listdir(layouts)):
        if not (file_name.startswith("dungeon_maps") and file_name.endswith(".json")):
            continue
        layout_path = os.path.join(layouts, file_name)
        layout = json.load(open(layout_path, encoding="utf-8"))
        tabs = layout["ffcc_dungeon_maps"]["tabs"]
        tabs[:] = [t for t in tabs if t.get("title") != TAB_TITLE] + [tab]
        with open(layout_path, "w", encoding="utf-8") as f:
            f.write(json.dumps(layout, indent=2) + "\n")

    init_path = os.path.join(pack, "scripts", "init.lua")
    init = open(init_path, encoding="utf-8").read()
    load = 'ScriptHost:LoadScript("scripts/bonus.lua")'
    if load not in init:
        init = init.replace('Tracker:AddLayouts("layouts/dungeon_maps_h.json")',
                            load + '\nTracker:AddLayouts("layouts/dungeon_maps_h.json")')
        with open(init_path, "w", encoding="utf-8") as f:
            f.write(init)
