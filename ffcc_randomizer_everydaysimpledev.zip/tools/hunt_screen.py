"""
The "Monster Hunt" tab: every enemy type of the hunt as a name card, grouped
by the dungeon it appears in most. A card is greyed out until that enemy type
has been defeated. Bosses have a gold border. The tooltip lists every dungeon
(and cycles) the enemy appears in.

Data comes from the AP world's monster_table.py and, at run time, the enemy
types the FFCC client records in data storage (ffcc_hunt_<team>_<slot> =
{enemy: true}), which it does whether or not "Monster Hunt Checks" is on.
Clicking a card marks it defeated (left) or not (right), for games played
without the AP client.

In a seed with "Monster Hunt Checks: Enemy Types", the enemy pins on the
dungeon maps (made by gen_pack.py) of every type already defeated or marked
are cleared, so the pins left show the enemies still to hunt. With "Every
Enemy" each pin is its own AP location and the autotracker clears it.

Writes scripts/hunt.lua, images/hunt/<code>.png and the tab in every
layouts/dungeon_maps*.json, and loads the script from scripts/init.lua.
"""

import importlib.util
import json
import os

TAB_TITLE = "Monster Hunt"
CARD_SIZE = (124, 28)
COLUMNS = 2                 # cards per row in a dungeon's group
LUA_TEMPLATE = r'''-- The Monster Hunt tab.

HUNT_ENEMIES = {
%(enemies)s
}

-- enemy type -> the tracker sections of its enemy pins
HUNT_SECTIONS = {
%(sections)s
}

HUNT_MODE = 0                           -- the seed's Monster Hunt Checks: 0 off, 1 types, 2 every enemy

local defeated = {}                     -- enemy -> true, from the FFCC client
local marks = {}                        -- enemy -> true, marked by clicking
local cards = {}                        -- enemy -> item

-- true if any of the enemy type's pins can be reached (in logic)
local function reachable(enemy)
    for _, ref in ipairs(HUNT_SECTIONS[enemy] or {}) do
        local section = Tracker:FindObjectForCode(ref)
        local level = section and section.AccessibilityLevel
        if level == AccessibilityLevel.Normal or level == AccessibilityLevel.Cleared then
            return true
        end
    end
    return false
end

local refreshing = false                -- HuntRefresh changes items, which can call it again
local shown = {}                        -- enemy -> icon path on its card now

function HuntRefresh()
    if refreshing then return end
    refreshing = true
    for _, info in ipairs(HUNT_ENEMIES) do
        local item = cards[info.name]
        local done = defeated[info.name] == true
        local state = done and " (defeated)" or marks[info.name] and " (marked)" or ""
        local icon = info.card
        if state == "" then
            local open = reachable(info.name)
            icon = open and info.open or info.closed
            state = open and " (in logic)" or " (out of logic)"
        end
        local name = info.name .. state .. " - " .. info.where
        if item.Name ~= name then item.Name = name end
        if shown[info.name] ~= icon then
            item.Icon = ImageReference:FromPackRelativePath(icon)
            shown[info.name] = icon
        end
    end
    -- Enemy Types: a defeated (or marked) type clears all of its pins
    if HUNT_MODE == 1 then
        for enemy, refs in pairs(HUNT_SECTIONS) do
            local count = (defeated[enemy] or marks[enemy]) and 0 or 1
            for _, ref in ipairs(refs) do
                local section = Tracker:FindObjectForCode(ref)
                if section and section.AvailableChestCount ~= count then
                    section.AvailableChestCount = count
                end
            end
        end
    end
    refreshing = false
end

for _, info in ipairs(HUNT_ENEMIES) do
    local item = ScriptHost:CreateLuaItem()
    local name = info.name
    item.Name = name
    item.Icon = ImageReference:FromPackRelativePath(info.card)
    item.CanProvideCodeFunc = function(self, wanted) return wanted == info.code end
    item.ProvidesCodeFunc = function(self, wanted) return 0 end
    item.OnLeftClickFunc = function(self) marks[name] = not marks[name] or nil; HuntRefresh() end
    item.OnRightClickFunc = function(self) marks[name] = nil; HuntRefresh() end
    item.SaveFunc = function(self) return {marked = marks[name] == true} end
    item.LoadFunc = function(self, data)
        marks[name] = type(data) == "table" and data.marked == true or nil
        HuntRefresh()
    end
    cards[name] = item
end

local function hunt_key()
    return "ffcc_hunt_" .. Archipelago.TeamNumber .. "_" .. Archipelago.PlayerNumber
end

local function on_records(key, value)
    if key ~= hunt_key() then return end
    defeated = {}
    if type(value) == "table" then
        for enemy, on in pairs(value) do
            if on then defeated[enemy] = true end
        end
    end
    HuntRefresh()
end

if Archipelago and Archipelago.AddSetReplyHandler then
    Archipelago:AddClearHandler("monster hunt", function(slot_data)
        local mode = slot_data and slot_data["monster_hunt_checks"]
        HUNT_MODE = mode == true and 1 or tonumber(mode) or 0
        defeated = {}
        Archipelago:SetNotify({hunt_key()})
        Archipelago:Get({hunt_key()})
        HuntRefresh()
    end)
    Archipelago:AddRetrievedHandler("monster hunt", on_records)
    Archipelago:AddSetReplyHandler("monster hunt", function(key, value) on_records(key, value) end)
end

-- what is in logic changes with every item, so the card borders follow
ScriptHost:AddWatchForCode("monster hunt logic", "*", function(code) HuntRefresh() end)

HuntRefresh()
'''


def _load_table(world):
    spec = importlib.util.spec_from_file_location("ffcc_monster_table", os.path.join(world, "monster_table.py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _lua_str(text):
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _font(size):
    from PIL import ImageFont
    for name in ("arialbd.ttf", "arial.ttf", "DejaVuSans-Bold.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


def _wrap(draw, text, font, width):
    """`text` split into lines that fit `width` pixels (at most two)."""
    words, lines = text.split(), [""]
    for word in words:
        trial = (lines[-1] + " " + word).strip()
        if draw.textlength(trial, font=font) <= width or not lines[-1]:
            lines[-1] = trial
        else:
            lines.append(word)
    return lines[:2]


# Card looks: "done" (defeated or marked: bright, gold border for a boss),
# "open" (still to defeat and in logic: dim, green border) and "closed"
# (still to defeat and out of logic: dim, red border).
CARD_STYLES = {
    "done":   {"fill": (40, 46, 60, 255), "text": (240, 240, 240, 255)},
    "open":   {"fill": (24, 26, 32, 255), "text": (150, 150, 155, 255), "outline": (70, 200, 90, 255)},
    "closed": {"fill": (24, 26, 32, 255), "text": (150, 150, 155, 255), "outline": (210, 60, 60, 255)},
}


def _card(path, text, boss, style="done"):
    """A dark rounded card with the enemy's name, in one of CARD_STYLES."""
    from PIL import Image, ImageDraw
    w, h = CARD_SIZE
    look = CARD_STYLES[style]
    image = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    outline = look.get("outline") or ((230, 190, 70, 255) if boss else (150, 150, 170, 255))
    draw.rounded_rectangle((1, 1, w - 2, h - 2), radius=5, fill=look["fill"], outline=outline, width=2)
    for size in (12, 11, 10, 9):
        font = _font(size)
        lines = _wrap(draw, text, font, w - 10)
        if all(draw.textlength(line, font=font) <= w - 10 for line in lines) and \
                len(lines) * (size + 1) <= h - 4:
            break
    total = len(lines) * (size + 1)
    y = (h - total) / 2 - 1
    for line in lines:
        x = (w - draw.textlength(line, font=font)) / 2
        draw.text((x, y), line, font=font, fill=look["text"])
        y += size + 1
    image.save(path)


def _where(cycles):
    parts = []
    for dungeon, dungeon_cycles in cycles.items():
        c = list(dungeon_cycles)
        span = "all cycles" if c == [1, 2, 3] else "cycle " + ", ".join(str(v) for v in c)
        parts.append(f"{dungeon} ({span})")
    return "; ".join(parts)


def write(pack, world, dungeons, enemy_sections=None):
    """`dungeons`: gen_pack's DUNGEONS ({name: (map, cycle code, colour)}).
    `enemy_sections`: gen_pack's ENEMY_SECTIONS ({location: section})."""
    table = _load_table(world)
    image_dir = os.path.join(pack, "images", "hunt")
    os.makedirs(image_dir, exist_ok=True)

    enemy_lines, groups = [], {}
    for name, (code, boss, _ids, main, cycles) in table.MONSTERS.items():
        cards = {style: f"images/hunt/{code}{'' if style == 'done' else '_' + style}.png" for style in CARD_STYLES}
        for style, card in cards.items():
            _card(os.path.join(pack, card), name, boss, style)
        where = ("Boss of " if boss else "Found in ") + _where(cycles)
        enemy_lines.append(f"    {{name = {_lua_str(name)}, code = \"hunt_{code}\", "
                           f"card = {_lua_str(cards['done'])}, open = {_lua_str(cards['open'])}, "
                           f"closed = {_lua_str(cards['closed'])}, where = {_lua_str(where)}}},")
        groups.setdefault(main, []).append(f"hunt_{code}")
    by_type = {}
    for location, section in (enemy_sections or {}).items():
        by_type.setdefault(table.ENEMIES[location][2], []).append(section)
    section_lines = [f"    [{_lua_str(enemy)}] = {{" + ", ".join(_lua_str(s) for s in refs) + "},"
                     for enemy, refs in by_type.items()]
    lua = LUA_TEMPLATE % {"enemies": "\n".join(enemy_lines), "sections": "\n".join(section_lines)}
    with open(os.path.join(pack, "scripts", "hunt.lua"), "w", encoding="utf-8") as f:
        f.write(lua)

    # one group per dungeon (in the pack's dungeon order), two cards a row
    boxes = []
    for dungeon in dungeons:
        codes = groups.get(dungeon)
        if not codes:
            continue
        rows = [codes[k:k + COLUMNS] for k in range(0, len(codes), COLUMNS)]
        boxes.append({"type": "group", "header": dungeon, "content": {
            "type": "itemgrid", "item_margin": "2,2", "item_width": CARD_SIZE[0],
            "item_height": CARD_SIZE[1], "rows": rows}})
    # The tab can't scroll, so the groups go in three rows of five.
    rows = [{"type": "array", "orientation": "horizontal", "margin": "4,4", "content": boxes[k:k + 5]}
            for k in range(0, len(boxes), 5)]
    tab = {"title": TAB_TITLE, "content": {"type": "container", "content": {
        "type": "array", "orientation": "vertical", "content": rows}}}
    layouts = os.path.join(pack, "layouts")
    for file_name in sorted(os.listdir(layouts)):
        if not (file_name.startswith("dungeon_maps") and file_name.endswith(".json")):
            continue
        layout_path = os.path.join(layouts, file_name)
        layout = json.load(open(layout_path, encoding="utf-8"))
        tabs = layout["ffcc_dungeon_maps"]["tabs"]
        tabs[:] = [t for t in tabs if t.get("title") != TAB_TITLE] + [tab]
        with open(layout_path, "w", encoding="utf-8") as f:
            f.write(json.dumps(layout, indent=2) + "\n")

    init_path = os.path.join(pack, "scripts", "init.lua")
    init = open(init_path, encoding="utf-8").read()
    load = 'ScriptHost:LoadScript("scripts/hunt.lua")'
    if load not in init:
        init = init.replace('Tracker:AddLayouts("layouts/dungeon_maps_h.json")',
                            load + '\nTracker:AddLayouts("layouts/dungeon_maps_h.json")')
        with open(init_path, "w", encoding="utf-8") as f:
            f.write(init)
