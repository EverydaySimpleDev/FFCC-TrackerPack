"""
gen_pack.py - rebuild the tracker's chest locations and AP location mapping
from the AP world, so they always match the game-order chest numbers.

Inputs
  tools/chests.json   chest positions in the game, written by the randomizer:
                        py chestflags.py positions Updated.iso <pack>/tools/chests.json
  tools/stagemaps/    map images drawn from the game's stage geometry, in several
                      variants (hotspot icons and enemy letters on or off), with
                      every chest's pixel position (stagemaps.json), written by the
                      randomizer:  py stagemap.py tracker Updated.iso <pack>/tools/stagemaps
                      A dungeon listed there uses those images and positions. The Map
                      Options items pick the variant (scripts/map_options.lua).
  tools/pins.json     map pin(s) per chest for dungeons without a stage map,
                      {dungeon: {"N": [x, y]}} or, for a chest with several spots,
                      {"N": [[x, y], [x, y]]}. Chests without a pin go in a row
                      along the bottom of the map.
  the AP world        worlds/ffcc (locations.py + chest_table.py) for names and IDs

Outputs
  locations/locations.json
  scripts/pop_tracker_ap_autotracking/location_mapping.lua  (LOCATION_MAPPING block only)
  tools/placement/<dungeon>.png   top-down plot of where each chest is in the game,
                                  numbered, to help place pins by eye

    py tools/gen_pack.py [path/to/worlds/ffcc]   (default: ../Archipelago/worlds/ffcc next to the pack)
"""

import importlib.util
import json
import os
import re
import sys
import types

from PIL import Image, ImageDraw

PACK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORLD = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(PACK), "Archipelago", "worlds", "ffcc")
AP_ID_BASE = 2326528

# dungeon: (tracker map name or None, cycle code prefix or None, colour)
DUNGEONS = {
    "River Belle Path":       ("river_belle_path",   "rbp",  "#4488ff"),
    "Goblin Wall":            ("goblin_wall",        "gw",   "#cc6633"),
    "The Mine of Cathuriges": ("mine_of_cathuriges", "moc",  "#aa8844"),
    "The Mushroom Forest":    ("mushroom_forest",    "tmf",  "#66aa44"),
    "Tida":                   ("tida",               "tida", "#888888"),
    "Moschet Manor":          ("moschet_manor",      "mm",   "#aa44aa"),
    "Mount Kilanda":          ("mount_kilanda",      "mk",   "#dd4422"),
    "Daemon's Court":         ("daemons_court",      "dc",   "#996633"),
    "Selepation Cave":        ("selepation_cave",    "sc",   "#44aaaa"),
    "Veo Lu Sluice":          ("veo_lu_sluice",      "vls",  "#3366cc"),
    "Lynari Desert":          ("lynari_desert",      "ld",   "#ddbb44"),
    "Conall Curach":          ("conall_curach",      "cc",   "#557744"),
    "Rebena Te Ra":           ("rebena_te_ra",       "rtr",  "#bb9966"),
    "Mount Vellenge":         ("mount_vellenge",     None,   "#662222"),
}


def load_world():
    """The AP world's LOCATION_TABLE, loaded without Archipelago itself."""
    sys.modules.setdefault("BaseClasses", types.SimpleNamespace(Location=object, Region=object))
    pkg = types.ModuleType("ffccworld")
    pkg.__path__ = []
    sys.modules["ffccworld"] = pkg
    for m in ("game_id", "chest_table", "monster_table", "shop_table", "locations"):
        spec = importlib.util.spec_from_file_location(f"ffccworld.{m}", os.path.join(WORLD, f"{m}.py"))
        mod = importlib.util.module_from_spec(spec)
        sys.modules[f"ffccworld.{m}"] = mod
        spec.loader.exec_module(mod)
    return sys.modules["ffccworld.locations"].LOCATION_TABLE


VARIANT_MAPS = {}    # tracker map name -> [map name of each image variant]

# Enemies item stages and the image variant suffix each one shows
ENEMY_STAGES = [("Enemies: Off", ""), ("Enemies: All Cycles", "e"), ("Enemies: Cycle 1", "e1"),
                ("Enemies: Cycle 2", "e2"), ("Enemies: Cycle 3", "e3")]


def _variant_map(map_name, suffix):
    return f"{map_name}__{suffix}" if suffix else map_name


def use_stage_maps():
    """Copy the stage map images (every variant) into the pack, add a map per
    variant to maps.json (and a tab in layouts/tracker.json for a dungeon that
    has none), and return {dungeon: {chest: [[x, y], ...]}}."""
    import shutil
    index_path = os.path.join(PACK, "tools", "stagemaps", "stagemaps.json")
    if not os.path.exists(index_path):
        return {}
    index = json.load(open(index_path, encoding="utf-8"))
    maps_path = os.path.join(PACK, "maps", "maps.json")
    maps = json.load(open(maps_path, encoding="utf-8"))
    by_name = {m["name"]: m for m in maps}
    layout_path = os.path.join(PACK, "layouts", "tracker.json")
    layout = original_layout = open(layout_path, encoding="utf-8").read()
    pins = {}
    for dungeon, entry in index.items():
        map_name = DUNGEONS[dungeon][0]
        VARIANT_MAPS[map_name] = []
        for suffix, file in sorted(entry.get("variants", {"": entry["img"]}).items()):
            name = _variant_map(map_name, suffix)
            img = f"images/maps/{map_name}_stage{'_' + suffix if suffix else ''}.jpg"
            shutil.copyfile(os.path.join(PACK, "tools", "stagemaps", file), os.path.join(PACK, img))
            if name not in by_name:
                by_name[name] = {"name": name, "location_size": 18, "location_border_thickness": 2}
                maps.append(by_name[name])
            by_name[name]["img"] = img
            if suffix:
                VARIANT_MAPS[map_name].append(name)
        maps_layout = os.path.join(PACK, "layouts", "dungeon_maps.json")
        known = layout + (open(maps_layout, encoding="utf-8").read() if os.path.exists(maps_layout) else "")
        if f'"{map_name}"' not in known:
            layout = _add_tab(layout, dungeon, map_name)
        pins[dungeon] = entry["pins"]
    with open(maps_path, "w", encoding="utf-8") as f:
        json.dump(maps, f, indent=2)
    if layout != original_layout:
        with open(layout_path, "w", encoding="utf-8") as f:
            f.write(layout)
    return pins


def _find_map_tabs(node):
    """The "tabbed" layout node whose tabs are the dungeon maps."""
    if isinstance(node, dict):
        if node.get("type") == "tabbed" and any(
                t.get("content", {}).get("type") == "map" for t in node.get("tabs", [])):
            return node
        for v in node.values():
            hit = _find_map_tabs(v)
            if hit:
                return hit
    elif isinstance(node, list):
        for v in node:
            hit = _find_map_tabs(v)
            if hit:
                return hit
    return None


def _add_tab(layout, title, map_name):
    """Add a map tab after the last dungeon tab of layouts/tracker.json."""
    data = json.loads(layout)
    tabs = _find_map_tabs(data)
    if tabs is not None:
        tabs["tabs"].append({"title": title, "content": {"type": "map", "maps": [map_name]}})
        return json.dumps(data, indent=2) + "\n"
    path = os.path.join(PACK, "layouts", "dungeon_maps.json")
    maps_layout = json.load(open(path, encoding="utf-8"))
    maps_layout["ffcc_dungeon_maps"]["tabs"].append({"title": title, "content": {"type": "map", "maps": [map_name]}})
    with open(path, "w", encoding="utf-8") as f:
        json.dump(maps_layout, f, indent=2)
    return layout


def write_map_options():
    """items/map_options.json and their icons: a Show Hotspots toggle, an
    Enemies item that steps through Off / All Cycles / Cycle 1 / 2 / 3, and an
    Auto Tab toggle that opens the map of the dungeon the player is in."""
    from PIL import ImageFont
    folder = os.path.join(PACK, "images", "options")
    os.makedirs(folder, exist_ok=True)
    for old in os.listdir(folder):
        os.remove(os.path.join(folder, old))
    try:
        font = ImageFont.truetype("arialbd.ttf", 30)
    except OSError:
        font = ImageFont.load_default()

    def icon(file, colour, text, outline="white"):
        img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        if text == "tab":
            d.rounded_rectangle([6, 14, 58, 54], 6, fill=colour, outline=outline, width=3)
            d.rectangle([6, 8, 30, 20], fill=colour, outline=outline, width=3)
            d.polygon([(22, 26), (46, 34), (22, 42)], fill="white")
        elif text == "H":
            d.polygon([(18, 34), (46, 34), (32, 60)], fill=colour)
            d.ellipse([12, 4, 52, 44], fill=colour, outline=outline, width=3)
            d.text((32, 25), "H", fill="white", font=font, anchor="mm")
        else:
            d.ellipse([6, 6, 58, 58], fill=colour, outline=outline, width=3)
            d.text((32, 33), text, fill="white", font=font, anchor="mm")
        img.save(os.path.join(folder, file))
        return f"images/options/{file}"

    items = [{"name": "Show Hotspots", "type": "toggle", "codes": "show_hotspots",
              "img": icon("show_hotspots.png", (60, 145, 245), "H"), "initial_active_state": True}]
    stages = []
    for i, (name, suffix) in enumerate(ENEMY_STAGES):
        text = {"": "E", "e": "E", "e1": "1", "e2": "2", "e3": "3"}[suffix]
        colour = (70, 70, 90) if not suffix else (160, 25, 35)
        stages.append({"name": name, "img": icon(f"show_enemies_{i}.png", colour, text)})
    items.append({"name": "Enemies", "type": "progressive", "codes": "show_enemies",
                  "allow_disabled": False, "stages": stages})
    items.append({"name": "Auto Tab to Current Stage", "type": "toggle", "codes": "auto_tab",
                  "img": icon("auto_tab.png", (40, 150, 90), "tab"), "initial_active_state": True})
    with open(os.path.join(PACK, "items", "map_options.json"), "w", encoding="utf-8") as f:
        json.dump(items, f, indent=2)


def write_map_layouts():
    """One layouts/dungeon_maps_<variant>.json per image variant, each holding
    the dungeon map tabs (layout key "ffcc_dungeon_maps") with that variant's
    maps, and scripts/map_options.lua, which loads the one matching the Map
    Options. layouts/tracker.json shows whichever was loaded last."""
    layout_path = os.path.join(PACK, "layouts", "tracker.json")
    layout = json.load(open(layout_path, encoding="utf-8"))
    tabs = _find_map_tabs(layout)
    if tabs is not None:
        template = json.loads(json.dumps(tabs))
        tabs.clear()
        tabs.update({"type": "layout", "key": "ffcc_dungeon_maps"})
        with open(layout_path, "w", encoding="utf-8") as f:
            f.write(json.dumps(layout, indent=2) + "\n")
        with open(os.path.join(PACK, "layouts", "dungeon_maps.json"), "w", encoding="utf-8") as f:
            json.dump({"ffcc_dungeon_maps": template}, f, indent=2)
    template = json.load(open(os.path.join(PACK, "layouts", "dungeon_maps.json"), encoding="utf-8"))["ffcc_dungeon_maps"]
    suffixes = [f"{h}{e}" for h in ("", "h") for _, e in ENEMY_STAGES]
    for suffix in suffixes:
        variant = json.loads(json.dumps(template))
        for tab in variant["tabs"]:
            content = tab.get("content", {})
            if content.get("type") == "map":
                content["maps"] = [_variant_map(m, suffix) if m in VARIANT_MAPS else m for m in content["maps"]]
        with open(os.path.join(PACK, "layouts", f"dungeon_maps_{suffix or 'plain'}.json"), "w",
                  encoding="utf-8") as f:
            json.dump({"ffcc_dungeon_maps": variant}, f, indent=2)
    stage_suffix = ", ".join(f'[{i}] = "{e}"' for i, (_, e) in enumerate(ENEMY_STAGES))
    lua = f"""-- Switches the dungeon map tabs to the image variant the Map Options ask for:
-- hotspot icons on or off, and which enemies' letters are drawn. With Auto Tab
-- on, it also opens the map of the dungeon the player is in, which the FFCC
-- client puts in the server's data storage as ffcc_stage_<team>_<slot>.

local ENEMY_SUFFIX = {{{stage_suffix}}}
local current = nil
local stage = ""

function ShowStageTab()
    local auto = Tracker:FindObjectForCode("auto_tab")
    if stage ~= "" and auto and auto.Active then
        pcall(function() Tracker:UiHint("ActivateTab", stage) end)
    end
end

function UpdateMapVariant()
    local hotspots = Tracker:FindObjectForCode("show_hotspots")
    local enemies = Tracker:FindObjectForCode("show_enemies")
    local suffix = ((hotspots and hotspots.Active) and "h" or "") ..
        (ENEMY_SUFFIX[enemies and enemies.CurrentStage or 0] or "")
    if suffix == "" then suffix = "plain" end
    if suffix ~= current then
        current = suffix
        Tracker:AddLayouts("layouts/dungeon_maps_" .. suffix .. ".json")
        ShowStageTab()
    end
end

ScriptHost:AddWatchForCode("map_options_hotspots", "show_hotspots", UpdateMapVariant)
ScriptHost:AddWatchForCode("map_options_enemies", "show_enemies", UpdateMapVariant)
ScriptHost:AddWatchForCode("map_options_auto_tab", "auto_tab", ShowStageTab)
UpdateMapVariant()

local function stage_key()
    return "ffcc_stage_" .. Archipelago.TeamNumber .. "_" .. Archipelago.PlayerNumber
end

local function on_stage(key, value)
    if key == stage_key() and type(value) == "string" and value ~= stage then
        stage = value
        ShowStageTab()
    end
end

if Archipelago and Archipelago.AddSetReplyHandler then
    Archipelago:AddClearHandler("stage tab", function()
        stage = ""
        Archipelago:SetNotify({{stage_key()}})
        Archipelago:Get({{stage_key()}})
    end)
    Archipelago:AddRetrievedHandler("stage tab", on_stage)
    Archipelago:AddSetReplyHandler("stage tab", function(key, value) on_stage(key, value) end)
end
"""
    with open(os.path.join(PACK, "scripts", "map_options.lua"), "w", encoding="utf-8") as f:
        f.write(lua)


def add_map_options_to_pack():
    """Load the map options in scripts/init.lua and show them in a "Map
    Options" group of layouts/tracker.json."""
    init_path = os.path.join(PACK, "scripts", "init.lua")
    init = original = open(init_path, encoding="utf-8").read()
    init = init.replace('Tracker:AddLocations("locations/map_info.json")\n', "")
    if 'Tracker:AddItems("items/map_options.json")' not in init:
        init = init.replace('Tracker:AddItems("items/items.json")',
                            'Tracker:AddItems("items/items.json")\nTracker:AddItems("items/map_options.json")')
    if 'layouts/dungeon_maps_h.json' not in init:
        init = init.replace('Tracker:AddLayouts("layouts/tracker.json")',
                            'Tracker:AddLayouts("layouts/dungeon_maps_h.json")\n'
                            'Tracker:AddLayouts("layouts/tracker.json")\n'
                            'ScriptHost:LoadScript("scripts/map_options.lua")')
    if init != original:
        with open(init_path, "w", encoding="utf-8") as f:
            f.write(init)
    old_pins = os.path.join(PACK, "locations", "map_info.json")
    if os.path.exists(old_pins):
        os.remove(old_pins)
    layout_path = os.path.join(PACK, "layouts", "tracker.json")
    layout = json.load(open(layout_path, encoding="utf-8"))
    left = next(c for c in layout["tracker_default"]["content"]["content"] if c.get("dock") == "left")
    group = next((g for g in left["content"] if g.get("header") == "Map Options"), None)
    if group is None:
        group = {"type": "group", "header": "Map Options", "dock": "top",
                 "content": {"type": "itemgrid", "item_margin": "4,1", "h_alignment": "left", "rows": []}}
        left["content"].insert(1, group)
    group["content"]["rows"] = [["show_hotspots", "show_enemies", "auto_tab"]]
    with open(layout_path, "w", encoding="utf-8") as f:
        f.write(json.dumps(layout, indent=2) + "\n")


def map_sizes():
    maps = json.load(open(os.path.join(PACK, "maps", "maps.json"), encoding="utf-8"))
    out = {}
    for m in maps:
        with Image.open(os.path.join(PACK, m["img"])) as im:
            out[m["name"]] = im.size
    return out


def placement_plot(dungeon, chests, path):
    """Top-down (x, z) plot per area, chest numbers drawn at their spots."""
    areas = sorted({c["area"] for c in chests})
    W, H, pad = 420, 420, 30
    img = Image.new("RGB", (W * len(areas), H + 24), "white")
    d = ImageDraw.Draw(img)
    for i, area in enumerate(areas):
        pts = [c for c in chests if c["area"] == area]
        xs = [c["world"][0] for c in pts]
        zs = [c["world"][2] for c in pts]
        span = max(max(xs) - min(xs), max(zs) - min(zs), 1)
        ox = i * W
        d.rectangle([ox + 2, 2, ox + W - 2, H - 2], outline="#999")
        d.text((ox + 8, H + 4), f"{dungeon} - area {area}", fill="black")
        for c in pts:
            px = ox + pad + (c["world"][0] - min(xs)) / span * (W - 2 * pad)
            py = pad + (c["world"][2] - min(zs)) / span * (H - 2 * pad)
            col = "#c00" if c["items"] else "#999"
            d.ellipse([px - 4, py - 4, px + 4, py + 4], fill=col)
            d.text((px + 6, py - 6), str(c["chest"]) + ("" if c["items"] else " gil"), fill=col)
    img.save(path)


# Stage keys (AP option Stage Keys): one per dungeon but River Belle Path.
# (dungeon, AP item code) in the AP world's order, items.py STAGE_KEYS.
# Shop Checks: town -> tracker map name. tools/stagemaps/towns.json holds the
# images and each shop's pin, written by the randomizer:
#     py stagemap.py towns Updated.iso <pack>/tools/stagemaps
TOWN_MAPS = {"Tipa": "town_tipa", "Port Tipa": "town_port_tipa", "Marr's Pass": "town_marrs_pass",
             "Alfitaria": "town_alfitaria", "West Jegon River": "town_west_jegon_river",
             "Fields of Fum": "town_fields_of_fum", "Shella": "town_shella", "Leuda": "town_leuda",
             "Mag Mell": "town_mag_mell"}
# What each town needs, as in the AP world's rules.py: the year its world-map
# area opens, Fields of Fum is across the Jegon River, and Shella only lets
# in a caravan with a Shella Mark, dropped by the enemies of Veo Lu Sluice
TOWN_RULES = {"Marr's Pass": [], "Alfitaria": ["$year|2"], "Shella": ["$year|2", "$stage_key|vls"],
              "Fields of Fum": ["$year|3", "$across_river"], "Leuda": ["$year|5"]}
# shops that are only there in some years, said in their names
SHOP_YEARS = {"marrs_pass": "odd years", "alfitaria_materials": "even years", "fum_materials": "odd years"}


def shop_locations(mapping):
    """The "FFCC Shops" locations: one per shop, a section per slot, pinned
    on its town's map. Adds the town maps to maps.json and a "Towns" tab
    (one inner tab per town) to the dungeon map tabs."""
    import shutil
    index_path = os.path.join(PACK, "tools", "stagemaps", "towns.json")
    if not os.path.exists(index_path):
        return []
    towns = json.load(open(index_path, encoding="utf-8"))
    shops = sys.modules["ffccworld.shop_table"]
    maps_path = os.path.join(PACK, "maps", "maps.json")
    maps = json.load(open(maps_path, encoding="utf-8"))
    by_name = {m["name"]: m for m in maps}
    for town, map_name in TOWN_MAPS.items():
        img = f"images/maps/{map_name}.jpg"
        shutil.copyfile(os.path.join(PACK, "tools", "stagemaps", towns[town]["img"]), os.path.join(PACK, img))
        if map_name not in by_name:
            by_name[map_name] = {"name": map_name, "location_size": 26, "location_border_thickness": 3}
            maps.append(by_name[map_name])
        by_name[map_name]["img"] = img
    with open(maps_path, "w", encoding="utf-8") as f:
        json.dump(maps, f, indent=2)

    path = os.path.join(PACK, "layouts", "dungeon_maps.json")
    maps_layout = json.load(open(path, encoding="utf-8"))
    tabs = maps_layout["ffcc_dungeon_maps"]["tabs"]
    tab = {"title": "Towns", "content": {"type": "tabbed", "tabs": [
        {"title": town, "content": {"type": "map", "maps": [map_name]}} for town, map_name in TOWN_MAPS.items()]}}
    old = next((i for i, t in enumerate(tabs) if t.get("title") in ("Shops", "Towns")), None)
    if old is None:
        tabs.append(tab)
    else:
        tabs[old] = tab
    with open(path, "w", encoding="utf-8") as f:
        json.dump(maps_layout, f, indent=2)

    children = []
    for key, (display, town, _, _, count) in shops.SHOPS.items():
        rule = TOWN_RULES[town]
        label = f"{display} ({SHOP_YEARS[key]})" if key in SHOP_YEARS else display
        sections = []
        for name, (code, shop, slot, _) in shops.LOCATIONS.items():
            if shop != key:
                continue
            sec = {"name": f"Slot {slot}", "item_count": 1}
            if rule:
                sec["access_rules"] = [",".join(rule)]
            sections.append(sec)
            mapping.append((AP_ID_BASE + code, f"@{label}/Slot {slot}", None))
        x, y = towns[town]["pins"][key]
        children.append({"name": label, "visibility_rules": ["$shops_shown"], "sections": sections,
                         "map_locations": [{"map": TOWN_MAPS[town], "x": x, "y": y}]})
    return children


# Mog Stamps: the tracker's short name for each Moogle Nest (on its icon)
STAMP_LABELS = {"Tipa": "TIPA", "Port Tipa": "PORT", "Marr's Pass": "MARR", "Alfitaria": "ALFI",
                "Shella": "SHEL", "The Fields of Fum": "FUM", "West Jegon River": "JEGN",
                "Leuda": "LEUD", "Mag Mell": "MAG"}
# a town's nest: its tracker town (TOWN_MAPS) and what it needs, as in the
# AP world's rules.py. Mag Mell is in the Abyss, on the way to Mount Vellenge.
STAMP_TOWNS = {"Tipa": ("Tipa", []), "Port Tipa": ("Port Tipa", []),
               "Marr's Pass": ("Marr's Pass", TOWN_RULES["Marr's Pass"]),
               "Alfitaria": ("Alfitaria", TOWN_RULES["Alfitaria"]),
               "Shella": ("Shella", TOWN_RULES["Shella"]),
               "The Fields of Fum": ("Fields of Fum", TOWN_RULES["Fields of Fum"]),
               "West Jegon River": ("West Jegon River", TOWN_RULES["Fields of Fum"]),
               "Leuda": ("Leuda", TOWN_RULES["Leuda"]),
               "Mag Mell": ("Mag Mell", ["$stage_key|mv", "$river|mv"])}
STAMP_COLUMNS = 8


def _slug(name):
    return re.sub(r"\W+", "_", name.lower().replace("'", "")).strip("_")


def mog_stamp_locations():
    """The Mog Stamps: an item per Moogle Nest (items/mog_stamps.json, in a
    "Mog Stamps" group of layouts/tracker.json), a pin per nest on its
    dungeon's or town's map (shown with the Mog Stamps goal or Mog Stamp
    Hints, $stamps_shown), the icons, drawn from one of the game's own
    stamps (images/stamps/stamp_art.png, from dvd/menu/stamp.tex), and
    scripts/stamps.lua, which marks the stamps the FFCC client reports."""
    from PIL import ImageFont, ImageOps
    world = sys.modules["ffccworld.locations"]
    stagemaps = json.load(open(os.path.join(PACK, "tools", "stagemaps", "stagemaps.json"), encoding="utf-8"))
    towns = json.load(open(os.path.join(PACK, "tools", "stagemaps", "towns.json"), encoding="utf-8"))
    folder = os.path.join(PACK, "images", "stamps")
    art = Image.open(os.path.join(folder, "stamp_art.png")).convert("RGBA")
    try:
        font = ImageFont.truetype("arialbd.ttf", 15)
    except OSError:
        font = ImageFont.load_default()

    def grey(img):
        out = ImageOps.grayscale(img).convert("RGBA")
        out.putalpha(img.getchannel("A"))
        return out

    pin = art.resize((32, 32), Image.LANCZOS)
    pin.save(os.path.join(folder, "pin.png"))
    grey(pin).save(os.path.join(folder, "pin_collected.png"))

    # towns first, then the dungeons in the tracker's order
    order = list(STAMP_TOWNS) + [d for d in DUNGEONS if d in world.MOG_STAMP_NESTS]
    assert sorted(order) == sorted(world.MOG_STAMP_NESTS), "a Moogle Nest has no tracker place"
    items, children, lua_rows = [], [], []
    for nest in order:
        code = f"stamp_{_slug(nest)}"
        label = STAMP_LABELS.get(nest) or RULE_CODES[nest].upper()
        icon = art.resize((64, 64), Image.LANCZOS)
        d = ImageDraw.Draw(icon)
        d.text((32, 56), label, fill="white", font=font, anchor="mm", stroke_width=3, stroke_fill="black")
        icon.save(os.path.join(folder, f"{code}.png"))
        items.append({"name": f"Mog Stamp - {nest}", "type": "toggle", "codes": code,
                      "img": f"images/stamps/{code}.png"})

        location = world.mog_stamp_location(nest)
        if nest in DUNGEONS:
            map_name, rule_code, _ = DUNGEONS[nest]
            rule = [f"$stage_key|{KEY_CODES[nest]}"] if nest in KEY_CODES else []
            rule.append(f"$river|{RULE_CODES[nest]}")
            spot = stagemaps.get(nest, {}).get("moogle_pin")
            maps = [map_name] + VARIANT_MAPS.get(map_name, [])
        else:
            town, rule = STAMP_TOWNS[nest]
            spot = towns.get(town, {}).get("pins", {}).get("moogle")
            maps = [TOWN_MAPS[town]]
        section = {"name": "Mog Stamp", "item_count": 1}
        if rule:
            section["access_rules"] = [",".join(rule)]
        loc = {"name": location, "chest_unopened_img": "images/stamps/pin.png",
               "chest_opened_img": "images/stamps/pin_collected.png",
               "visibility_rules": ["$stamps_shown"], "sections": [section]}
        if spot:
            loc["map_locations"] = [{"map": m, "x": spot[0], "y": spot[1]} for m in maps]
        else:
            print(f"  no map pin for the {nest} Moogle Nest")
        children.append(loc)
        lua_rows.append(f'    {{bit = {world.mog_stamp_bit(nest)}, code = "{code}", '
                        f'section = "@{location}/Mog Stamp"}},')

    with open(os.path.join(PACK, "items", "mog_stamps.json"), "w", encoding="utf-8") as f:
        json.dump(items, f, indent=2)

    lua = """-- Mog Stamps: lights the stamp items and clears the Moogle Nest pins of the
-- stamps the save has. The FFCC client puts them in the server's data
-- storage as ffcc_mog_stamps_<team>_<slot>: the 4 stamp bytes at 0x8021EF56
-- read as one big-endian number, a bit per nest. The pins only show with
-- the Mog Stamps goal or Mog Stamp Hints ($stamps_shown).

local STAMPS = {
""" + "\n".join(lua_rows) + """
}

STAMPS_SHOWN = false

function stamps_shown()
    return STAMPS_SHOWN
end

local function stamps_key()
    return "ffcc_mog_stamps_" .. Archipelago.TeamNumber .. "_" .. Archipelago.PlayerNumber
end

-- numbers from the server can arrive as floats, so the bits are tested
-- with arithmetic
local function has_bit(value, bit)
    return math.floor(value / bit) % 2 == 1
end

local function show_stamps(value)
    if type(value) ~= "number" then
        return
    end
    for _, stamp in ipairs(STAMPS) do
        if has_bit(value, stamp.bit) then
            local item = Tracker:FindObjectForCode(stamp.code)
            if item and not item.Active then
                item.Active = true
            end
            local section = Tracker:FindObjectForCode(stamp.section)
            if section and section.AvailableChestCount ~= 0 then
                section.AvailableChestCount = 0
            end
        end
    end
end

if Archipelago and Archipelago.AddSetReplyHandler then
    Archipelago:AddClearHandler("mog stamps", function(slot_data)
        local goal = slot_data and tonumber(slot_data["victory_goal"])
        local hints = slot_data and slot_data["mog_stamp_hints"]
        STAMPS_SHOWN = goal == 3 or hints == true or (type(hints) == "number" and hints ~= 0)
        for _, stamp in ipairs(STAMPS) do
            local item = Tracker:FindObjectForCode(stamp.code)
            if item then
                item.Active = false
            end
            local section = Tracker:FindObjectForCode(stamp.section)
            if section then
                section.AvailableChestCount = section.ChestCount
            end
        end
        Archipelago:SetNotify({stamps_key()})
        Archipelago:Get({stamps_key()})
    end)
    Archipelago:AddRetrievedHandler("mog stamps", function(key, value)
        if key == stamps_key() then show_stamps(value) end
    end)
    Archipelago:AddSetReplyHandler("mog stamps", function(key, value)
        if key == stamps_key() then show_stamps(value) end
    end)
end
"""
    with open(os.path.join(PACK, "scripts", "stamps.lua"), "w", encoding="utf-8") as f:
        f.write(lua)

    init_path = os.path.join(PACK, "scripts", "init.lua")
    init = original = open(init_path, encoding="utf-8").read()
    if 'Tracker:AddItems("items/mog_stamps.json")' not in init:
        init = init.replace('Tracker:AddItems("items/spell_rings.json")',
                            'Tracker:AddItems("items/spell_rings.json")\nTracker:AddItems("items/mog_stamps.json")')
    if 'scripts/stamps.lua' not in init:
        # before the locations, whose $stamps_shown rule it defines
        init = init.replace('ScriptHost:LoadScript("scripts/logic.lua")',
                            'ScriptHost:LoadScript("scripts/logic.lua")\nScriptHost:LoadScript("scripts/stamps.lua")')
    if init != original:
        with open(init_path, "w", encoding="utf-8") as f:
            f.write(init)

    layout_path = os.path.join(PACK, "layouts", "tracker.json")
    layout = json.load(open(layout_path, encoding="utf-8"))
    left = next(c for c in layout["tracker_default"]["content"]["content"] if c.get("dock") == "left")
    group = next((g for g in left["content"] if g.get("header") == "Mog Stamps"), None)
    if group is None:
        group = {"type": "group", "header": "Mog Stamps", "dock": "top",
                 "content": {"type": "itemgrid", "item_margin": "4,1", "h_alignment": "left", "rows": []}}
        rings = next((i for i, g in enumerate(left["content"]) if g.get("header") == "Extra Spell Rings"), 0)
        left["content"].insert(rings + 1, group)
    codes = [item["codes"] for item in items]
    group["content"]["rows"] = [codes[i:i + STAMP_COLUMNS] for i in range(0, len(codes), STAMP_COLUMNS)]
    with open(layout_path, "w", encoding="utf-8") as f:
        f.write(json.dumps(layout, indent=2) + "\n")
    return children


STAGE_KEY_ITEMS = [
    ("Goblin Wall", 0x210), ("The Mine of Cathuriges", 0x211), ("The Mushroom Forest", 0x212),
    ("Tida", 0x213), ("Moschet Manor", 0x214), ("Mount Kilanda", 0x215), ("Daemon's Court", 0x216),
    ("Selepation Cave", 0x217), ("Veo Lu Sluice", 0x218), ("Lynari Desert", 0x219),
    ("Conall Curach", 0x21a), ("Rebena Te Ra", 0x21b), ("Mount Vellenge", 0x21c),
]
AP_ITEM_ID_BASE = 2322432
KEY_CODES = {d: DUNGEONS[d][1] or "mv" for d, _ in STAGE_KEY_ITEMS}
RULE_CODES = {d: code or "mv" for d, (_, code, _) in DUNGEONS.items()}
# World-map spots across the Jegon River (Plains of Fum, Rebena Plains, the
# Abyss), as in the AP world's rules.py (RIVER_CROSSING and the areas past it)
# Same as CHEST_NEEDS_DUNGEON and REBENA_TIMED_CHESTS in the AP world's rules.py.
CHEST_NEEDS_DUNGEON = {
    ("Conall Curach", 12): "Daemon's Court",   # behind the log bridge bombed in Daemon's Court
    ("Conall Curach", 21): "Daemon's Court",
}
TIMED_CHESTS = {("Rebena Te Ra", 6), ("Rebena Te Ra", 9)}

ACROSS_RIVER = ["Selepation Cave", "Daemon's Court", "Conall Curach", "Rebena Te Ra", "Mount Vellenge"]


def write_stage_keys():
    """The stage keys as tracker items (key_<dungeon code>), a "Stage Keys
    Required" toggle that the AP slot data sets, scripts/logic.lua with the
    $stage_key rule every chest of a keyed dungeon uses, the AP item mapping
    for the keys, and a "Stage Keys" group in layouts/tracker.json."""
    from PIL import ImageFont
    folder = os.path.join(PACK, "images", "keys")
    os.makedirs(folder, exist_ok=True)
    try:
        font = ImageFont.truetype("arialbd.ttf", 17)
    except OSError:
        font = ImageFont.load_default()

    def icon(file, colour, text):
        img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        d.ellipse([4, 4, 32, 32], fill=colour, outline="white", width=3)
        d.ellipse([12, 12, 24, 24], fill=(0, 0, 0, 0), outline="white", width=2)
        d.rectangle([27, 15, 58, 21], fill=colour, outline="white", width=2)
        d.rectangle([44, 21, 50, 30], fill=colour, outline="white", width=2)
        d.rectangle([53, 21, 58, 27], fill=colour, outline="white", width=2)
        d.text((40, 50), text, fill="white", font=font, anchor="mm", stroke_width=2, stroke_fill="black")
        img.save(os.path.join(folder, file))
        return f"images/keys/{file}"

    items = [{"name": "Stage Keys Required", "type": "toggle", "codes": "stage_keys_on",
              "img": icon("stage_keys_on.png", (150, 150, 160), "ON"), "initial_active_state": False}]
    for dungeon, _ in STAGE_KEY_ITEMS:
        code = KEY_CODES[dungeon]
        items.append({"name": f"{dungeon} Key", "type": "toggle", "codes": f"key_{code}",
                      "img": icon(f"key_{code}.png", DUNGEONS[dungeon][2], code.upper())})
    with open(os.path.join(PACK, "items", "stage_keys.json"), "w", encoding="utf-8") as f:
        json.dump(items, f, indent=2)

    dungeon_of_code = "\n".join(f'    {RULE_CODES[d]} = "{d}",' for d in DUNGEONS)
    far_spots = "\n".join(f'    ["{spot}"] = true,' for spot in ACROSS_RIVER)
    with open(os.path.join(PACK, "scripts", "logic.lua"), "w", encoding="utf-8") as f:
        f.write("""-- The same rules as the AP world's logic (worlds/ffcc/rules.py).

-- $stage_key|<code>: a dungeon's chests are in logic once its key is found,
-- or always when the seed has no stage keys ("Stage Keys Required" off).
function stage_key(code)
    local on = Tracker:FindObjectForCode("stage_keys_on")
    if not (on and on.Active) then
        return true
    end
    local key = Tracker:FindObjectForCode("key_" .. code)
    return key ~= nil and key.Active
end

-- $river|<code>: a dungeon on a spot across the Jegon River (Plains of Fum,
-- Rebena Plains, the Abyss) needs the Ring of Life and Veo Lu Sluice, so the
-- river can be refilled when it dries up in Year 5. With Shuffle Loading
-- Zones the spot comes from the slot data (SetWorldZones).
local DUNGEON_OF_CODE = {
""" + dungeon_of_code + """
}
local ACROSS_RIVER = {
""" + far_spots + """
}
local SPOT_OF = {}      -- dungeon -> world-map spot, empty = every dungeon on its own

function SetWorldZones(zones)
    SPOT_OF = {}
    if type(zones) == "table" then
        for spot, dungeon in pairs(zones) do
            SPOT_OF[dungeon] = spot
        end
    end
end

function river(code)
    local dungeon = DUNGEON_OF_CODE[code]
    if not ACROSS_RIVER[SPOT_OF[dungeon] or dungeon] then
        return true
    end
    local ring = Tracker:FindObjectForCode("ring_of_life")
    return ring ~= nil and ring.Active and stage_key("vls")
end

-- $timed_chests: Rebena Te Ra chests 6 and 9 need tight timing alone. They are
-- in logic only with the "Rebena Te Ra Timed Chests" option. Otherwise they
-- show as a sequence break.
TIMED_CHESTS_ON = false

function timed_chests()
    if TIMED_CHESTS_ON then
        return true
    end
    return AccessibilityLevel.SequenceBreak
end

-- $progression_cycle|<cycle>: cycles past the "Progression Cycles" option only
-- hold filler, so they show as a sequence break (safe to skip).
PROGRESSION_CYCLES = 3

function progression_cycle(cycle)
    if tonumber(cycle) <= PROGRESSION_CYCLES then
        return true
    end
    return AccessibilityLevel.SequenceBreak
end

-- $chests_shown: with "Monster Hunt Checks" the enemies are the checks and
-- the chests are gone, so their map pins are hidden.
CHESTS_SHOWN = true

function chests_shown()
    return CHESTS_SHOWN
end

-- $shops_shown: the shop pins of "Shop Checks"
SHOPS_SHOWN = false

function shops_shown()
    return SHOPS_SHOWN
end

-- $year|<n>: the game is in year n or later (the Year Tracker, which the
-- client keeps up to date)
function year(n)
    local tracker = Tracker:FindObjectForCode("year_tracker")
    return tracker ~= nil and tracker.CurrentStage + 1 >= tonumber(n)
end

-- $across_river: the Fields of Fum, across the Jegon River like the
-- dungeons there (see river)
function across_river()
    local ring = Tracker:FindObjectForCode("ring_of_life")
    return ring ~= nil and ring.Active and stage_key("vls")
end

-- $enemies_shown|<enemy or boss>: the enemy pins of "Monster Hunt Checks",
-- bosses only with "Monster Hunt Bosses".
ENEMIES_SHOWN = false
HUNT_BOSSES = true

function enemies_shown(kind)
    return ENEMIES_SHOWN and (kind ~= "boss" or HUNT_BOSSES)
end

-- $exit_shown|<option>: the pin of an exit that only exists with that
-- option (Lynari Desert North Exit). archipelago.lua fills EXITS_ON from
-- the slot data.
EXITS_ON = {}

function exit_shown(option)
    return EXITS_ON[option] == true
end
""")

    path = os.path.join(PACK, "scripts", "pop_tracker_ap_autotracking", "item_mapping.lua")
    text = open(path, encoding="utf-8").read()
    text = re.sub(r'    \[\d+\] = \{"key_\w+", "toggle"\},[^\n]*\n', "", text)
    lines = "".join(f'    [{AP_ITEM_ID_BASE + code}] = {{"key_{KEY_CODES[d]}", "toggle"}},  -- {d} Key\n'
                    for d, code in STAGE_KEY_ITEMS)
    end = text.rindex("\n}")
    with open(path, "w", encoding="utf-8") as f:
        f.write(text[:end + 1] + lines + text[end + 1:])

    init_path = os.path.join(PACK, "scripts", "init.lua")
    init = original = open(init_path, encoding="utf-8").read()
    if 'Tracker:AddItems("items/stage_keys.json")' not in init:
        init = init.replace('Tracker:AddItems("items/items.json")',
                            'Tracker:AddItems("items/items.json")\nTracker:AddItems("items/stage_keys.json")')
    if 'ScriptHost:LoadScript("scripts/logic.lua")' not in init:
        init = init.replace('Tracker:AddMaps("maps/maps.json")',
                            'ScriptHost:LoadScript("scripts/logic.lua")\nTracker:AddMaps("maps/maps.json")')
    if init != original:
        with open(init_path, "w", encoding="utf-8") as f:
            f.write(init)

    layout_path = os.path.join(PACK, "layouts", "tracker.json")
    layout = json.load(open(layout_path, encoding="utf-8"))
    left = next(c for c in layout["tracker_default"]["content"]["content"] if c.get("dock") == "left")
    group = next((g for g in left["content"] if g.get("header") == "Stage Keys"), None)
    if group is None:
        group = {"type": "group", "header": "Stage Keys", "dock": "top",
                 "content": {"type": "itemgrid", "item_margin": "4,1", "h_alignment": "left", "rows": []}}
        cycles = next((i for i, g in enumerate(left["content"]) if g.get("header") == "Dungeon Cycles"), 0)
        left["content"].insert(cycles + 1, group)
    codes = ["stage_keys_on"] + [f"key_{KEY_CODES[d]}" for d, _ in STAGE_KEY_ITEMS]
    group["content"]["rows"] = [codes[:7], codes[7:]]
    with open(layout_path, "w", encoding="utf-8") as f:
        f.write(json.dumps(layout, indent=2) + "\n")


# Progressive equipment (AP option Progressive Equipment): (name, code, AP item
# code, picture letter). The tracker counts how many of each have arrived.
EQUIPMENT_ITEMS = [
    ("Progressive Weapon",      "prog_weapon", 0x220, "W"),
    ("Progressive Armor",       "prog_armor",  0x221, "A"),
    ("Progressive Tribal Gear", "prog_tribal", 0x222, "T"),
]
EQUIPMENT_STEPS = 6


def write_equipment_items():
    """items/equipment.json (a counter per progressive equipment item), their
    icons, the AP item mapping, and an "Equipment" group in layouts/tracker.json."""
    from PIL import ImageFont
    folder = os.path.join(PACK, "images", "equipment")
    os.makedirs(folder, exist_ok=True)
    try:
        font = ImageFont.truetype("arialbd.ttf", 30)
    except OSError:
        font = ImageFont.load_default()
    items = []
    for name, code, _, letter in EQUIPMENT_ITEMS:
        img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        d.polygon([(32, 4), (58, 16), (52, 46), (32, 60), (12, 46), (6, 16)],
                  fill=(150, 120, 60), outline="white", width=3)
        d.text((32, 32), letter, fill="white", font=font, anchor="mm")
        img.save(os.path.join(folder, f"{code}.png"))
        items.append({"name": name, "type": "consumable", "codes": code,
                      "img": f"images/equipment/{code}.png", "max_quantity": EQUIPMENT_STEPS})
    with open(os.path.join(PACK, "items", "equipment.json"), "w", encoding="utf-8") as f:
        json.dump(items, f, indent=2)

    path = os.path.join(PACK, "scripts", "pop_tracker_ap_autotracking", "item_mapping.lua")
    text = open(path, encoding="utf-8").read()
    text = re.sub(r'    \[\d+\] = \{"prog_\w+", "consumable"\},[^\n]*\n', "", text)
    lines = "".join(f'    [{AP_ITEM_ID_BASE + ap_code}] = {{"{code}", "consumable"}},  -- {name}\n'
                    for name, code, ap_code, _ in EQUIPMENT_ITEMS)
    end = text.rindex("\n}")
    with open(path, "w", encoding="utf-8") as f:
        f.write(text[:end + 1] + lines + text[end + 1:])

    init_path = os.path.join(PACK, "scripts", "init.lua")
    init = open(init_path, encoding="utf-8").read()
    if 'Tracker:AddItems("items/equipment.json")' not in init:
        init = init.replace('Tracker:AddItems("items/stage_keys.json")',
                            'Tracker:AddItems("items/stage_keys.json")\nTracker:AddItems("items/equipment.json")')
        with open(init_path, "w", encoding="utf-8") as f:
            f.write(init)

    layout_path = os.path.join(PACK, "layouts", "tracker.json")
    layout = json.load(open(layout_path, encoding="utf-8"))
    left = next(c for c in layout["tracker_default"]["content"]["content"] if c.get("dock") == "left")
    group = next((g for g in left["content"] if g.get("header") == "Equipment"), None)
    if group is None:
        group = {"type": "group", "header": "Equipment", "dock": "top",
                 "content": {"type": "itemgrid", "item_margin": "4,1", "h_alignment": "left", "rows": []}}
        keys = next((i for i, g in enumerate(left["content"]) if g.get("header") == "Stage Keys"), 0)
        left["content"].insert(keys + 1, group)
    group["content"]["rows"] = [[code for _, code, _, _ in EQUIPMENT_ITEMS]]
    with open(layout_path, "w", encoding="utf-8") as f:
        f.write(json.dumps(layout, indent=2) + "\n")


# Extra spell rings (AP option Extra Spell Rings): (name, code, AP item code,
# picture of the game ring whose menu icon it borrows)
SPELL_RING_ITEMS = [
    ("Ring of Gravity", "ring_of_gravity", 0xf6, "artifact_12"),
    ("Ring of Holy",    "ring_of_holy",    0xf7, "artifact_10"),
    ("Ring of Slow",    "ring_of_slow",    0xf8, "artifact_9"),
    ("Ring of Stop",    "ring_of_stop",    0xf9, "artifact_9"),
    ("Ring of Haste",   "ring_of_haste",   0xfa, "artifact_11"),
]


def write_spell_rings():
    """items/spell_rings.json, the AP item mapping, and an "Extra Spell
    Rings" group in layouts/tracker.json, after the Equipment group."""
    items = [{"name": name, "type": "toggle", "codes": code, "img": f"images/items/{img}.png"}
             for name, code, _, img in SPELL_RING_ITEMS]
    with open(os.path.join(PACK, "items", "spell_rings.json"), "w", encoding="utf-8") as f:
        json.dump(items, f, indent=2)

    path = os.path.join(PACK, "scripts", "pop_tracker_ap_autotracking", "item_mapping.lua")
    text = open(path, encoding="utf-8").read()
    codes = "|".join(code for _, code, _, _ in SPELL_RING_ITEMS)
    text = re.sub(rf'    \[\d+\] = \{{"(?:{codes})", "toggle"\}},[^\n]*\n', "", text)
    lines = "".join(f'    [{AP_ITEM_ID_BASE + ap_code}] = {{"{code}", "toggle"}},  -- {name}\n'
                    for name, code, ap_code, _ in SPELL_RING_ITEMS)
    end = text.rindex("\n}")
    with open(path, "w", encoding="utf-8") as f:
        f.write(text[:end + 1] + lines + text[end + 1:])

    init_path = os.path.join(PACK, "scripts", "init.lua")
    init = open(init_path, encoding="utf-8").read()
    if 'Tracker:AddItems("items/spell_rings.json")' not in init:
        init = init.replace('Tracker:AddItems("items/equipment.json")',
                            'Tracker:AddItems("items/equipment.json")\nTracker:AddItems("items/spell_rings.json")')
        with open(init_path, "w", encoding="utf-8") as f:
            f.write(init)

    layout_path = os.path.join(PACK, "layouts", "tracker.json")
    layout = json.load(open(layout_path, encoding="utf-8"))
    left = next(c for c in layout["tracker_default"]["content"]["content"] if c.get("dock") == "left")
    group = next((g for g in left["content"] if g.get("header") == "Extra Spell Rings"), None)
    if group is None:
        group = {"type": "group", "header": "Extra Spell Rings", "dock": "top",
                 "content": {"type": "itemgrid", "item_margin": "4,1", "h_alignment": "left", "rows": []}}
        equipment = next((i for i, g in enumerate(left["content"]) if g.get("header") == "Equipment"), 0)
        left["content"].insert(equipment + 1, group)
    group["content"]["rows"] = [[code for _, code, _, _ in SPELL_RING_ITEMS]]
    with open(layout_path, "w", encoding="utf-8") as f:
        f.write(json.dumps(layout, indent=2) + "\n")


def write_cycle_tracking():
    """scripts/cycles.lua: sets the dungeon cycle trackers and the year
    tracker from what the FFCC client puts in the server's data storage
    (ffcc_cycles_<team>_<slot>, {dungeon: 1-3, "Year": n}), and loads it from
    scripts/init.lua after the AP scripts."""
    codes = "\n".join(f'    ["{d}"] = "cycle_{code}",' for d, (_, code, _) in DUNGEONS.items() if code)
    items = json.load(open(os.path.join(PACK, "items", "items.json"), encoding="utf-8"))
    year_item = next(i for i in items if i.get("codes") == "year_tracker")
    year_stages = ", ".join(str(n) for n in range(1, len(year_item["stages"]) + 1))
    lua = f"""-- Moves each dungeon's cycle tracker up to the cycle the game is on, and the
-- year tracker up to the game's year. The FFCC client puts them in the
-- server's data storage as ffcc_cycles_<team>_<slot> = {{dungeon name: 1-3,
-- Year = n}}.

local CYCLE_CODES = {{
{codes}
}}

-- one entry per stage of the Year Tracker item
local YEAR_STAGES = {{{year_stages}}}

local function cycles_key()
    return "ffcc_cycles_" .. Archipelago.TeamNumber .. "_" .. Archipelago.PlayerNumber
end

local function on_cycles(key, value)
    if key ~= cycles_key() or type(value) ~= "table" then
        return
    end
    local year = Tracker:FindObjectForCode("year_tracker")
    if year and type(value["Year"]) == "number" then
        -- stage 0 is Year 1
        local stage = math.min(math.floor(value["Year"]) - 1, #YEAR_STAGES - 1)
        if stage > year.CurrentStage then
            year.CurrentStage = stage
        end
    end
    for dungeon, cycle in pairs(value) do
        local code = CYCLE_CODES[dungeon]
        local obj = code and Tracker:FindObjectForCode(code)
        -- The cycle icons have an "off" state, so in Lua stage 0 is off and
        -- stage N is Cycle N. Numbers from the server can arrive as floats
        -- (2.0), and a float CurrentStage is ignored, hence math.floor.
        local stage = type(cycle) == "number" and math.floor(cycle) or 0
        if obj and stage >= 1 and obj.CurrentStage < stage then
            obj.CurrentStage = stage
        end
    end
end

if Archipelago and Archipelago.AddSetReplyHandler then
    Archipelago:AddClearHandler("cycle tracking", function()
        Archipelago:SetNotify({{cycles_key()}})
        Archipelago:Get({{cycles_key()}})
    end)
    Archipelago:AddRetrievedHandler("cycle tracking", on_cycles)
    Archipelago:AddSetReplyHandler("cycle tracking", function(key, value) on_cycles(key, value) end)
end
"""
    with open(os.path.join(PACK, "scripts", "cycles.lua"), "w", encoding="utf-8") as f:
        f.write(lua)
    init_path = os.path.join(PACK, "scripts", "init.lua")
    init = open(init_path, encoding="utf-8").read()
    load = 'ScriptHost:LoadScript("scripts/pop_tracker_ap_autotracking/archipelago.lua")'
    if "scripts/cycles.lua" not in init:
        init = init.replace(load, load + '\n    ScriptHost:LoadScript("scripts/cycles.lua")')
        with open(init_path, "w", encoding="utf-8") as f:
            f.write(init)


def _enemy_image(path, colour):
    """A small round marker for enemy locations (the pin's popup)."""
    from PIL import Image, ImageDraw
    image = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    ImageDraw.Draw(image).ellipse((3, 3, 28, 28), fill=colour, outline=(255, 235, 235, 255), width=3)
    image.save(path)


# Exits that only exist with an option (stagemaps.json's "exit_pins", from
# stagemap.OPTIONAL_EXITS): {pin name: (option in the slot data, section name)}
OPTIONAL_EXITS = {
    "North Exit": ("lynari_desert_north_exit", "Quicksand to Area 2"),
}


def exit_locations(dungeon, map_name):
    """A pin for each optional exit of a dungeon, shown only when the seed
    has its option on ($exit_shown). It is not a check, just a marker."""
    index_path = os.path.join(PACK, "tools", "stagemaps", "stagemaps.json")
    pins = json.load(open(index_path, encoding="utf-8")).get(dungeon, {}).get("exit_pins", {})
    if not pins or not map_name:
        return []
    from PIL import Image, ImageDraw
    image = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    ImageDraw.Draw(image).polygon([(16, 2), (30, 16), (16, 30), (2, 16)],
                                  fill=(235, 190, 60, 255), outline=(70, 50, 10, 255), width=3)
    image.save(os.path.join(PACK, "images", "exit.png"))
    out = []
    for name, (x, y) in sorted(pins.items()):
        option, section = OPTIONAL_EXITS[name]
        out.append({"name": f"{dungeon} - {name}",
                    "chest_unopened_img": "images/exit.png", "chest_opened_img": "images/exit.png",
                    "visibility_rules": [f"$exit_shown|{option}"],
                    "sections": [{"name": section, "item_count": 0}],
                    "map_locations": [{"map": m, "x": x, "y": y}
                                      for m in [map_name] + VARIANT_MAPS.get(map_name, [])]})
    return out


# location name -> its tracker section ("@<location>/<section>"), for every
# enemy of ENEMIES. hunt_screen.py uses it to clear the pins of defeated
# enemy types.
ENEMY_SECTIONS = {}


def _cycle_text(dungeon, cycles):
    """ "cycle 1", "cycles 2-3", "all cycles" ... for a section name."""
    cycles = sorted(cycles)
    if dungeon == "Mount Vellenge" or cycles == [1, 2, 3]:
        return "all cycles"
    if len(cycles) == 1:
        return f"cycle {cycles[0]}"
    if cycles == list(range(cycles[0], cycles[-1] + 1)):
        return f"cycles {cycles[0]}-{cycles[-1]}"
    return "cycles " + ", ".join(str(c) for c in cycles)


PIN_NUDGE = 16      # pixels between the pins of enemies that spawn on one spot together


def enemy_locations(dungeon, map_name, code, sizes, mapping):
    """The enemy locations of a dungeon (monster_table.py's ENEMIES): a pin
    per spawn spot (stagemaps.json's "monster_pins"), and one "Boss Fight"
    pin, along the bottom of the map, for the enemies of the boss rooms,
    which aren't on the map. A later cycle often puts a different enemy on
    the same spot, so enemies that share a spot in different cycles share a
    pin, with a section each, named with the cycles it appears in. Enemies
    that spawn on the same spot together get a pin each, side by side
    (PIN_NUDGE), so each one clears on its own. They only show in seeds with
    Monster Hunt checks ($enemies_shown), bosses only with Monster Hunt
    Bosses. With "Every Enemy" each section is its own AP location. With
    "Enemy Types" hunt.lua clears the sections of every enemy type already
    defeated."""
    enemies = sys.modules["ffccworld.monster_table"].ENEMIES
    monsters = sys.modules["ffccworld.monster_table"].MONSTERS
    index_path = os.path.join(PACK, "tools", "stagemaps", "stagemaps.json")
    pins = json.load(open(index_path, encoding="utf-8")).get(dungeon, {}).get("monster_pins", {})
    _enemy_image(os.path.join(PACK, "images", "enemy.png"), (190, 30, 40, 255))
    _enemy_image(os.path.join(PACK, "images", "enemy_defeated.png"), (90, 90, 90, 255))
    images = {"chest_unopened_img": "images/enemy.png", "chest_opened_img": "images/enemy_defeated.png"}
    maps = [map_name] + VARIANT_MAPS.get(map_name, [])
    spots, boss_room = {}, []    # spots: pin -> [(location name, section)]
    for name, (ap_code, where, enemy, _id, area, entry, _pos, cycles) in enemies.items():
        if where != dungeon:
            continue
        cycle = 1 if dungeon == "Mount Vellenge" else min(cycles)
        rule = [f"cycle_{code}_c{cycle}"] if cycle >= 2 and code else []
        if dungeon in KEY_CODES:
            rule.append(f"$stage_key|{KEY_CODES[dungeon]}")
        rule.append(f"$river|{RULE_CODES[dungeon]}")
        if cycle >= 2:
            rule.append(f"$progression_cycle|{cycle}")
        section = {"name": f"{name[len(dungeon) + 3:]} ({_cycle_text(dungeon, cycles)})", "item_count": 1,
                   "access_rules": [",".join(rule)],
                   "visibility_rules": [f"$enemies_shown|{'boss' if monsters[enemy][1] else 'enemy'}"]}
        pin = pins.get(f"{area}#{entry}")
        if pin is None:
            boss_room.append((name, section))
        else:
            spots.setdefault(tuple(pin), []).append((name, section, set(cycles)))
        mapping.append((AP_ID_BASE + ap_code, name, None))     # completed below with the location name

    out = []
    groups = []
    for (x, y), members in spots.items():
        pins_here = []      # [members] - each pin's enemies appear in different cycles
        for name, section, cyc in members:
            pin_members = next((m for m in pins_here if all(not cyc & c for _, _, c in m)), None)
            if pin_members is None:
                pin_members = []
                pins_here.append(pin_members)
            pin_members.append((name, section, cyc))
        for k, pin_members in enumerate(pins_here):
            groups.append(((x + k * PIN_NUDGE, y), [(n, sec) for n, sec, _ in pin_members]))
    if boss_room:
        w, h = sizes[map_name]
        groups.append(((w - 30, h - 30), boss_room))
    for pin, members in groups:
        if members is boss_room:
            location = f"{dungeon} - Boss Fight"
        elif len(members) == 1:
            location = members[0][0]
        else:
            location = f"{dungeon} - " + " / ".join(n[len(dungeon) + 3:] for n, _ in members)
        for name, section in members:
            ENEMY_SECTIONS[name] = f"@{location}/{section['name']}"
        out.append(dict(images, name=location, visibility_rules=["$enemies_shown|enemy"],
                        sections=[s for _, s in members],
                        map_locations=[{"map": m, "x": pin[0], "y": pin[1]} for m in maps]))
    # the AP ids point at the sections
    for i, (ap_id, target, comment) in enumerate(mapping):
        if target in ENEMY_SECTIONS:
            mapping[i] = (ap_id, ENEMY_SECTIONS[target], comment)
    return out


def main():
    table = load_world()
    chests = json.load(open(os.path.join(PACK, "tools", "chests.json"), encoding="utf-8"))
    pins_path = os.path.join(PACK, "tools", "pins.json")
    pins = json.load(open(pins_path, encoding="utf-8")) if os.path.exists(pins_path) else {}
    pins.update(use_stage_maps())
    sizes = map_sizes()
    os.makedirs(os.path.join(PACK, "tools", "placement"), exist_ok=True)

    # AP locations by (dungeon, chest) -> {cycle: ap id}
    by_chest, events = {}, []
    for name, d in table.items():
        ap_id = AP_ID_BASE + d.code
        if d.is_event:
            events.append((ap_id, name, d))
        else:
            by_chest.setdefault((d.region, d.chest), {})[d.cycle] = ap_id

    dungeons_json, mapping, unplaced = [], [], 0
    for dungeon, (map_name, code, colour) in DUNGEONS.items():
        rows = [c for c in chests.get(dungeon, []) if (dungeon, c["chest"]) in by_chest]
        placement_plot(dungeon, chests.get(dungeon, []),
                       os.path.join(PACK, "tools", "placement", re.sub(r"\W+", "_", dungeon).strip("_") + ".png"))
        children, spare = [], 0
        for c in rows:
            label = f"{dungeon} - Chest {c['chest']}"
            sections = []
            for cycle, ap_id in sorted(by_chest[(dungeon, c["chest"])].items()):
                sec = {"name": f"Cycle {cycle}", "item_count": 1}
                rule = [f"cycle_{code}_c{cycle}"] if cycle >= 2 and code else []
                if dungeon in KEY_CODES:
                    rule.append(f"$stage_key|{KEY_CODES[dungeon]}")
                rule.append(f"$river|{RULE_CODES[dungeon]}")
                other = CHEST_NEEDS_DUNGEON.get((dungeon, c["chest"]))
                if other:
                    rule += [f"$stage_key|{KEY_CODES[other]}", f"$river|{RULE_CODES[other]}"]
                if (dungeon, c["chest"]) in TIMED_CHESTS:
                    rule.append("$timed_chests")
                if cycle >= 2:
                    rule.append(f"$progression_cycle|{cycle}")
                if rule:
                    sec["access_rules"] = [",".join(rule)]
                sections.append(sec)
                mapping.append((ap_id, f"@{label}/Cycle {cycle}", None))
            loc = {"name": label,
                   "chest_unopened_img": "images/chest_unopened.png",
                   "chest_opened_img": "images/chest_opened.png",
                   "visibility_rules": ["$chests_shown"],
                   "sections": sections}
            if map_name:
                pin = pins.get(dungeon, {}).get(str(c["chest"]))
                if pin is None:
                    # not placed yet: a row along the bottom of the map
                    w, h = sizes[map_name]
                    pin = [30 + spare * 36, h - 30]
                    spare += 1
                    unplaced += 1
                points = pin if isinstance(pin[0], list) else [pin]
                loc["map_locations"] = [{"map": m, "x": int(x), "y": int(y)} for x, y in points
                                        for m in [map_name] + VARIANT_MAPS.get(map_name, [])]
            children.append(loc)
        children += enemy_locations(dungeon, map_name, code, sizes, mapping)
        children += exit_locations(dungeon, map_name)
        dungeons_json.append({"name": dungeon, "color": colour, "children": children})

    # cycle / year events keep their "=code:stage" form
    codes = {d: code for d, (_, code, _) in DUNGEONS.items()}
    for ap_id, name, d in sorted(events):
        m = re.match(r"(.+) - Cycle (\d) Reached", name)
        if m and codes.get(m.group(1)):
            # stage N is Cycle N: the cycle icons have an "off" stage 0
            mapping.append((ap_id, f"={'cycle_' + codes[m.group(1)]}:{int(m.group(2))}", name))
        m = re.match(r"Year (\d+) Begins", name)
        if m:
            mapping.append((ap_id, f"=year_tracker:{int(m.group(1)) - 1}", name))

    shops_json = shop_locations(mapping)
    stamps_json = mog_stamp_locations()
    with open(os.path.join(PACK, "locations", "locations.json"), "w", encoding="utf-8") as f:
        json.dump([{"name": "FFCC Dungeons", "children": dungeons_json},
                   {"name": "FFCC Shops", "children": shops_json},
                   {"name": "FFCC Mog Stamps", "children": stamps_json}], f, indent=2)

    write_tracker_names(mapping)

    lua_path = os.path.join(PACK, "scripts", "pop_tracker_ap_autotracking", "location_mapping.lua")
    old = open(lua_path, encoding="utf-8").read()
    tail = old[old.index("\n}\n") + 3:]
    lines = ["LOCATION_MAPPING = {"]
    for ap_id, target, comment in sorted(mapping):
        lines.append(f'    [{ap_id}] = {{"{target}"}},' + (f"  -- {comment}" if comment else ""))
    lines.append("}")
    with open(lua_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n" + tail)

    write_pin_editor(dungeons_json, pins)
    write_stage_keys()
    write_cycle_tracking()
    write_equipment_items()
    write_spell_rings()
    write_map_options()
    write_map_layouts()
    add_map_options_to_pack()
    import bonus_screen
    bonus_screen.write(PACK, WORLD, DUNGEONS)
    import hunt_screen
    hunt_screen.write(PACK, WORLD, DUNGEONS, ENEMY_SECTIONS)

    chest_count = sum(1 for d in dungeons_json for c in d["children"] if " - Chest " in c["name"])
    print(f"{chest_count} chests, {len(mapping)} AP ids mapped, "
          f"{unplaced} pin(s) still to place (bottom row of their map), "
          f"{sum(len(v) for v in VARIANT_MAPS.values())} map variant(s)")


def write_tracker_names(mapping):
    """The AP world's tracker_names.py: {"<pin>/<section>": AP id} for every
    pin section of the pack (chests, enemies, shop slots), which Universal
    Tracker uses to put the pack's pins on its map page and mark hinted ones."""
    names = {target[1:]: ap_id for ap_id, target, _ in mapping if target.startswith("@")}
    lines = [f"    {name!r}: {ap_id}," for name, ap_id in sorted(names.items(), key=lambda kv: kv[1])]
    header = [
        '"""',
        'PIN_SECTIONS = {"<pack location>/<section>": AP location id} for every',
        "pin section of the PopTracker pack, for Universal Tracker's map page.",
        '"""',
        "",
        "PIN_SECTIONS = {",
    ]
    text = "\n".join(header + lines + ["}"]) + "\n"
    with open(os.path.join(WORLD, "tracker_names.py"), "w", encoding="utf-8") as f:
        f.write(text)


def write_pin_editor(dungeons_json, pins):
    """tools/pin_editor.html: click a chest, click the map, Save -> pins.json."""
    maps = {m["name"]: "../" + m["img"] for m in
            json.load(open(os.path.join(PACK, "maps", "maps.json"), encoding="utf-8"))}
    data = []
    for d in dungeons_json:
        map_name = DUNGEONS[d["name"]][0]
        if not map_name:
            continue
        data.append({"dungeon": d["name"], "img": maps[map_name],
                     "plot": "placement/" + re.sub(r"\W+", "_", d["name"]).strip("_") + ".png",
                     "chests": [int(c["name"].rsplit(" ", 1)[1]) for c in d["children"]
                                if " - Chest " in c["name"]]})
    html = PIN_EDITOR.replace("__DATA__", json.dumps(data)).replace("__PINS__", json.dumps(pins))
    with open(os.path.join(PACK, "tools", "pin_editor.html"), "w", encoding="utf-8") as f:
        f.write(html)


PIN_EDITOR = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>FFCC Pin Editor</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  :root { --bg:#1c1c1e; --panel:#2a2a2d; --text:#eee; --muted:#999; --accent:#4a9eff; --done:#3c3; }
  body { margin:0; font:14px system-ui, sans-serif; background:var(--bg); color:var(--text); }
  header { padding:10px 16px; display:flex; gap:12px; align-items:center; flex-wrap:wrap; background:var(--panel); }
  select, button { font:inherit; padding:6px 10px; border-radius:6px; border:1px solid #555; background:#333; color:var(--text); }
  button.primary { background:var(--accent); border-color:var(--accent); color:#fff; }
  main { display:flex; gap:16px; padding:16px; align-items:flex-start; flex-wrap:wrap; }
  #chests { display:flex; flex-wrap:wrap; gap:6px; max-width:320px; }
  #chests button { min-width:44px; }
  #chests button.placed { border-color:var(--done); color:var(--done); }
  #chests button.active { background:var(--accent); color:#fff; }
  #wrap { position:relative; display:inline-block; cursor:crosshair; }
  #map { display:block; max-width:none; }
  .pin { position:absolute; width:18px; height:18px; margin:-9px 0 0 -9px; border:3px solid #e33;
         border-radius:50%; box-sizing:border-box; pointer-events:none; }
  .pin span { position:absolute; left:16px; top:-6px; color:#e33; font-weight:700; text-shadow:0 0 3px #fff; }
  .pin.active { border-color:var(--accent); }
  .pin.active span { color:var(--accent); }
  #plot { max-width:320px; border:1px solid #555; margin-top:12px; background:#fff; }
  .hint { color:var(--muted); max-width:320px; }
</style></head><body>
<header>
  <strong>FFCC Pin Editor</strong>
  <select id="dungeon"></select>
  <span class="hint" id="status"></span>
  <button class="primary" id="save">Save pins.json</button>
</header>
<main>
  <div>
    <div class="hint">1. Click a chest number. 2. Click its spot on the map. Green = placed.
      Shift+click adds another spot for a chest that is in more than one place.
      The plot below shows where each chest is in the game (same orientation as the map).
      When done, Save, put pins.json in tools/ and run tools/gen_pack.py.</div>
    <div id="chests" style="margin-top:10px"></div>
    <img id="plot" alt="Chest layout in the game">
  </div>
  <div id="wrap"><img id="map" alt="Dungeon map"></div>
</main>
<script>
const DATA = __DATA__;
const pins = __PINS__;
let cur = 0, active = null;
const $ = id => document.getElementById(id);
DATA.forEach((d, i) => $("dungeon").add(new Option(d.dungeon, i)));
$("dungeon").onchange = e => { cur = +e.target.value; active = null; render(); };
function render() {
  const d = DATA[cur], p = pins[d.dungeon] || {};
  $("map").src = d.img; $("plot").src = d.plot;
  const box = $("chests"); box.innerHTML = "";
  d.chests.forEach(n => {
    const b = document.createElement("button");
    b.textContent = n;
    if (p[n]) b.classList.add("placed");
    if (n === active) b.classList.add("active");
    b.onclick = () => { active = n; render(); };
    box.appendChild(b);
  });
  document.querySelectorAll(".pin").forEach(e => e.remove());
  Object.entries(p).forEach(([n, pin]) => {
    (Array.isArray(pin[0]) ? pin : [pin]).forEach(xy => {
      const e = document.createElement("div");
      e.className = "pin" + (+n === active ? " active" : "");
      e.style.left = xy[0] + "px"; e.style.top = xy[1] + "px";
      e.innerHTML = "<span>" + n + "</span>";
      $("wrap").appendChild(e);
    });
  });
  const placed = d.chests.filter(n => p[n]).length;
  $("status").textContent = placed + " / " + d.chests.length + " placed" +
    (active ? " - placing chest " + active : "");
}
$("map").onclick = e => {
  if (active === null) return;
  const d = DATA[cur], p = (pins[d.dungeon] = pins[d.dungeon] || {});
  const xy = [Math.round(e.offsetX), Math.round(e.offsetY)];
  if (e.shiftKey && p[active]) {
    // another spot for the same chest
    p[active] = (Array.isArray(p[active][0]) ? p[active] : [p[active]]).concat([xy]);
  } else {
    p[active] = xy;
    const i = d.chests.indexOf(active);
    active = d.chests.find((n, k) => k > i && !p[n]) ?? null;
  }
  render();
};
$("save").onclick = () => {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([JSON.stringify(pins, null, 1)], {type: "application/json"}));
  a.download = "pins.json"; a.click();
};
render();
</script></body></html>
"""


if __name__ == "__main__":
    main()
